---
name: Ashwin Ranade
role: Teaching Assistant
email: ashwin.ranade@cs.ucla.edu
photo: ashwin.jpeg

---