---
name: Siddarth Krishnamoorthy
role: Teaching Assistant
email: siddarthk@cs.ucla.edu
photo: siddarth.jpg

---
