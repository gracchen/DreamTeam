---
name: Ruining Ding
role: Teaching Assistant
email: rding1507@g.ucla.edu
photo: ruining.jpeg

---

