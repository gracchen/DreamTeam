---
name: Matt Wang
role: Teaching Assistant
email: matt@matthewwang.me
website: https://matthewwang.me
photo: matt.jpg
---

[Schedule an appointment](https://mattxw.com/cal); **please check with Matt first!**
