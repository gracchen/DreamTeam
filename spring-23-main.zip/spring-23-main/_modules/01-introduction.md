---
title: Course Introduction
---

M Apr 3
: **Lecture**{: .label .label-blue }Course Introduction
  : [Lecture Notes]({{site.baseurl}}/lectures/01/), [Slides](https://docs.google.com/presentation/d/1_Qp3e4SwWRm46bqz7-QZBEvF8JrxcfaA/edit?usp=share_link&ouid=101757866260235503028&rtpof=true&sd=true)
