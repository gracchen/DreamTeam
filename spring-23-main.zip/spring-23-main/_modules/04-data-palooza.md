---
title: Data Palooza
---

M Apr 24
: **Lecture**{: .label .label-blue }Typing Deep Dive, Guest Brian Kernighan
  : [Lecture Notes]({{site.baseurl}}/lectures/07), [Slides](https://docs.google.com/presentation/d/196AgYxc9mFypCwZwHAMNtbylKsfsANX8/edit?usp=sharing&ouid=101757866260235503028&rtpof=true&sd=true)

W Apr 26
: **Lecture**{: .label .label-blue }Typing Deep Dive
  : [Lecture Notes]({{site.baseurl}}/lectures/08), [Slides](https://docs.google.com/presentation/d/196AgYxc9mFypCwZwHAMNtbylKsfsANX8/edit?usp=sharing&ouid=101757866260235503028&rtpof=true&sd=true)
: **Due**{: .label .label-red }HW 3
  : [Solutions](https://drive.google.com/file/d/1noGtLdcYdhorW5D38wPbVWeE7U8_Sb9n/view?usp=sharing)
: **Posted**{: .label .label-green }HW 4
  : [Gradescope](https://www.gradescope.com/courses/529662/assignments/2853324)

F Apr 28
: **Section**{: .label .label-purple }Discussion (Data Topics, Midterm Review)
  : [Discussion Resources](https://drive.google.com/drive/folders/1TBOqhuq2-JFEcW0KNkbnC6UXtpGUsATe)

M May 1
: **Lecture**{: .label .label-blue }Scoping, Garbage Collection
  : [Lecture Notes]({{site.baseurl}}/lectures/09), [Slides](https://docs.google.com/presentation/d/196AgYxc9mFypCwZwHAMNtbylKsfsANX8/edit?usp=sharing&ouid=101757866260235503028&rtpof=true&sd=true)
