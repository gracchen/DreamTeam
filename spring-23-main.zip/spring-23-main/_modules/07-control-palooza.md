---
title: Control Palooza
---

W May 31
: **Lecture**{: .label .label-blue }Expressions, Control Flow, Iterators
  : [Lecture Notes]({{site.baseurl}}/lectures/17), [Slides](https://docs.google.com/presentation/d/1u1PJH2L8Mi_010USm4ZkFaGQ5vJGHlyK/)

: **Due**{: .label .label-red }HW 8
  : [Solutions](https://drive.google.com/file/d/1ekzVs5aF1hjxMsH1OwAZkTXdRv2Yyj4R/view?usp=sharing)
: **Posted**{: .label .label-green }HW 9
  : [Gradescope](https://www.gradescope.com/courses/529662/assignments/2922061)

F Jun 2
: **Section**{: .label .label-purple }Discussion (control topics)
  : [Discussion Resources](https://drive.google.com/drive/folders/1TBOqhuq2-JFEcW0KNkbnC6UXtpGUsATe)

S Jun 4
: **Due**{: .label .label-red }Project 3
  : [Submission](https://www.gradescope.com/courses/529662/assignments/2906325)

M Jun 5
: **Lecture**{: .label .label-blue }Concurrency
  : [Lecture Notes]({{site.baseurl}}/lectures/18), [Slides](https://docs.google.com/presentation/d/1u1PJH2L8Mi_010USm4ZkFaGQ5vJGHlyK/)
