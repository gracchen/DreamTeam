---
title: Logical Programming
---

M Jun 5
: **Lecture**{: .label .label-blue }Logic Programming
  : [Lecture Notes]({{site.baseurl}}/lectures/18), [Slides](https://docs.google.com/presentation/d/1-lNmUwBASu-KslLvfHpr7up8yOyRZmpa/edit?usp=sharing&ouid=101757866260235503028&rtpof=true&sd=true)

W Jun 7
: **Lecture**{: .label .label-blue }Logic Programming
  : Lecture Notes, [Slides](https://docs.google.com/presentation/d/1-lNmUwBASu-KslLvfHpr7up8yOyRZmpa/edit?usp=sharing&ouid=101757866260235503028&rtpof=true&sd=true)

F Jun 9
: **Section**{: .label .label-purple }Discussion (Prolog, Final)
  : [Discussion Resources](https://drive.google.com/drive/folders/1TBOqhuq2-JFEcW0KNkbnC6UXtpGUsATe)
: **Due**{: .label .label-red }HW 9
  : [Solutions](https://drive.google.com/file/d/16f648EtHlRrA-2ORX2ZBmMO1jPw9huhj/view?usp=sharing)
