---
layout: page
title: Homeworks
description: Homeworks - graded on effort only.
---

Homeworks will be released and turned in via Gradescope.  You will find links to new homework assignments (as they are released) below.

- [Homework 1](https://www.gradescope.com/courses/529662/assignments/2801558), due **Wed Apr 12 at 11:59 PM**
  - [Homework 1 Solutions](https://drive.google.com/file/d/1UX8CIZpQxB-bTdzQZ1z9pZ9vJ6k5DvR8/)
- [Homework 2](https://www.gradescope.com/courses/529662/assignments/2818872), due **Wed Apr 19 at 11:59 PM**
  - [Homework 2 Solutions](https://drive.google.com/file/d/1UPfh_crB4VVvEWzFBHbgkNDXBWkgAya2/)
- [Homework 3](https://www.gradescope.com/courses/529662/assignments/2837211), due **Wed April 26 at 11:59 PM**
  - [Homework 3 Solutions](https://drive.google.com/file/d/1noGtLdcYdhorW5D38wPbVWeE7U8_Sb9n/)
- [Homework 4](https://www.gradescope.com/courses/529662/assignments/2853324), due **Wed May 3 at 11:59 PM**
  - [Homework 4 Solutions](https://drive.google.com/file/d/1OmyPc4XC8hGuu5stZDy38WArHTErcez8/)
- [Homework 5](https://www.gradescope.com/courses/529662/assignments/2871779), due **Wed May 10 at 11:59 PM**
  - [Homework 5 Solutions](https://drive.google.com/file/d/1anBgOp-fIRjKMitOk3mtalOovpyAYB2L/)
- [Homework 6](https://www.gradescope.com/courses/529662/assignments/2888320), due **Wed May 17 at 11:59 PM**
  - [Homework 6 Solutions](https://drive.google.com/file/d/1Erm20vmHuajW_Gjj7UjAQT12t35rtbrd/)
- [Homework 7](https://www.gradescope.com/courses/529662/assignments/2901030), due **Wed May 24 at 11:59 PM**
  - [Homework 7 Solutions](https://drive.google.com/file/d/1zeIxbX8bnVZhEdpU3fazx-fCIIQaEcc3/)
- [Homework 8](https://www.gradescope.com/courses/529662/assignments/2913550), due **Wed May 31 at 11:59 PM**
  - [Homework 8 Solutions](https://drive.google.com/file/d/1ekzVs5aF1hjxMsH1OwAZkTXdRv2Yyj4R/)
- [Homework 9](https://www.gradescope.com/courses/529662/assignments/2922061), due **Fri June 9 at 11:59 PM**
  - [Homework 9 Solutions](https://drive.google.com/file/d/16f648EtHlRrA-2ORX2ZBmMO1jPw9huhj/)
